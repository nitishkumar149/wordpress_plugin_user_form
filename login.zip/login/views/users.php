<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<style>
td {
    text-align: center;
    align-items: center;
    font-family: inherit;
    font-size: inherit;
    font-weight: inherit;
    line-height: inherit;
}
</style>
<body>
  <h2>Users List</h2>
</body>
</html>
<?php
session_start();
$email = $_SESSION['email'];
echo $email;
global $wpdb;
$table_name ='employee';
$results = $wpdb->get_results( "SELECT * FROM $table_name"); 
if(!empty($results))                     
 {    
    echo "<table width='100%' border='0'>";
    echo "<tbody>";
    echo "<th>Id</th>";echo "<th>Name</th>";echo "<th>City</th>";echo "<th>State</th>";echo "<th>Age</th>";echo "<th>Email</th>";      
    foreach($results as $row){   
      echo "<tr>";
      echo "<td>". $row->id ."</td>";
      echo "<td>". $row->name ."</td>";
      echo "<td>". $row->city ."</td>";
      echo "<td>". $row->state ."</td>";
      echo "<td>". $row->age ."</td>";
      echo "<td>". $row->email ."</td>";
      echo "</tr>";
    }
}
?>