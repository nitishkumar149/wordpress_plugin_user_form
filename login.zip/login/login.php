<?php
/*
*Plugin Name: WP User Login
*Plugin URI: https://www.intigate.co.in
*Author: www.intigate.co.in
*Author URI: https://www.intigate.co.in
*Description: Simple User Login.
*Version: 1.0.0
*Licence: GPL2
*Licence URI :
*Test Domain: login
*/

 define("PLUGIN_DIR_PATH",plugin_dir_path(__FILE__));
 define("PLUGIN_URL",plugins_url());

function add_my_custom_menu(){
	add_menu_page(
		"customplugin",//page title
		"Login",//menu title
		"manage_options",//admin level
		"custom-plugin1",//page slug
		"custom_admin_view",//callback function
		"dashicons-admin-network",//icon url
		5//positions
	);
	add_submenu_page(
		"custom-plugin1",//parent slug
		"Add New",//page title
		"Register",//menu title
		"manage_options",//capability = user_level access
		"add-new",//menu slug
		"add_new_function"//callback function
		
	);


}

add_action("admin_menu","add_my_custom_menu");

function custom_plugin_assects(){
	wp_enqueue_style(
			"cpl_style",
			PLUGIN_URL."/login/assects/css/style.css", 
			'',
			PLUGIN_VERSION,
			fasle
		);

	wp_enqueue_script(
			"cpl_script",
			PLUGIN_URL."/login/assects/js/script.js", 
			'',
			PLUGIN_VERSION,
			fasle
		);
	
	$object_array=array(
		"Name" =>"intigate", 
		"Author" =>"Nitish"
	);
	wp_localize_script("cpl_script","login",$object_array);
}
add_action("init","custom_plugin_assects");

function custom_admin_view(){
	//echo"<h2>Login</h2>";
	include PLUGIN_DIR_PATH."/views/login.php";
	//include_once "C:/xmp/xampp/htdocs/wordpress/wp-content/plugins/login/views/login.php";
}
 function add_new_function(){
	//echo"<h2>Register</h2>";
	include_once PLUGIN_DIR_PATH."/views/registration.php";
	//include_once "C:/xmp/xampp/htdocs/wordpress/wp-content/plugins/login/views/registration.php";
 }
function custom_plugin_tables(){
	global $wpdb;
	require_once(ABSPATH.'/wp-admin/includes/upgrade.php');
	if(count($wpdb->get_var('SHOW TABLES LIKE "employee"'))==0){
		$sql_query_to_create_table = "CREATE TABLE `employee`(
									`id` int(11) NOT NULL AUTO_INCREMENT,
									`name` varchar(150) DEFAULT NULL,
									`city` varchar(150) DEFAULT NULL,
									`state` varchar(150) DEFAULT NULL,
									`age` varchar(150) DEFAULT NULL,
									`email` varchar(150) DEFAULT NULL,
									`password` varchar(150) DEFAULT NULL,
									PRIMARY KEY (`id`)
									)ENGINE=MyISAM DEFAULT CHARSET=latin1";
		dbDelta($sql_query_to_create_table);
	}
}
register_activation_hook(__FILE__,'custom_plugin_tables');

function deactivate_table(){     global $wpdb;     $wpdb->query("DROP table IF
Exists employee"); } register_deactivation_hook(__FILE__,"deactivate_table");


